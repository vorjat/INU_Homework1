package application;

public enum Environment {
	Produkcyjne, Testowe, Deweloperskie
}
